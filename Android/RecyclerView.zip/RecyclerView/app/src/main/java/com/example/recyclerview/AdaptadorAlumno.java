package com.example.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdaptadorAlumno extends RecyclerView.Adapter<AlumnosViewHolder> implements View.OnClickListener {

    private ArrayList<Alumno> alumnos;
    private Context contexto;
    private View.OnClickListener mListener;

    public AdaptadorAlumno(ArrayList<Alumno> alumnos, Context contexto) {
        this.alumnos = alumnos;
        this.contexto = contexto;
    }

    @NonNull
    @Override
    public AlumnosViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.elemento_lista, parent, false);
        AlumnosViewHolder viewHolder = new AlumnosViewHolder(itemview, contexto);
        itemview.setOnClickListener(this);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull AlumnosViewHolder holder, int position) {
        Alumno alumno = alumnos.get(position);
        holder.bindAlumno(alumno);
    }

    @Override
    public int getItemCount() {
        return alumnos.size();
    }

    public void setOnClickListener(View.OnClickListener listener) {
        mListener = listener;
    }

    @Override
    public void onClick(View view) {
        if (mListener != null) {
            mListener.onClick(view);
        }
    }

}
