package com.example.practica_7_josepcliment;

import java.io.Serializable;

public enum Tipo implements Serializable {
    R2D2,
    BENDER,
    WALLE
}
